<?php
    echo JText::_("TPL_COMPANYLOGO_CUSTOM")
?>
<h1>Hello</h1>
